
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.6.3'
version = '1.6.3'
full_version = '1.6.3'
git_revision = '4ec4ab8d6ccc1cdb34b84fdcb66fde2cc0210dbf'
release = True

if not release:
    version = full_version
